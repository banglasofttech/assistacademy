<?php
symlink('/home/assistacademy/assistacademy/storage/app/public','/home/assistacademy/public_html/storage');
?>